function cambiarNombre(idH2){
    let nombre = prompt('Ingrese el nuevo nombre');
    document.getElementById(idH2).innerHTML = nombre;
}
